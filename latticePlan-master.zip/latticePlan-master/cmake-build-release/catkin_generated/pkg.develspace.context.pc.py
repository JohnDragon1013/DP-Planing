# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "".split(';') if "" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-llatticePlan;-lPCL".split(';') if "-llatticePlan;-lPCL" != "" else []
PROJECT_NAME = "latticePlan"
PROJECT_SPACE_DIR = "/home/jydragon/catkin_ws/src/latticePlan/cmake-build-release/devel"
PROJECT_VERSION = "0.0.0"
