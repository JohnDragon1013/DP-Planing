st-graph is not used now.    </br>    

TODO: translate obstacles from x,y to SL,then to ST,calculate their boundaries.</br>     

TODO: combine discrete path points with speed data(v,a,t).    

